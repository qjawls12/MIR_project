clear all; clc;

% convert format of each file from avi to mat

% If you have any question, please email to jangwon@usc.edu
% Jangwon Kim
% May 2nd 2014

input_dir = '../rtMRIdata/avi';		% directory of input avi data
out_dir = '../rtMRIdata/mat_init';	% directory of output mat data

mkdir(out_dir);

list_file = dir(fullfile(input_dir, '*.avi'));
num_file = length(list_file);

for iFile = 1:num_file

  iFile

  fpath = fullfile(input_dir, list_file(iFile).name);
  mri_data = Avi2MovieMat_jw(fpath);

  fpath = fullfile(out_dir, [list_file(iFile).name(1:end-4) '.mat']);
  save(fpath,'mri_data');
end
