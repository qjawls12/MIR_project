%% Paths
% - Assume that the rtMRI videos are in mat data format of N x M matrix
%     N x M; N is the number of frame, M is the number of pixels
% - directory path for the silence labels: [] if no silence label is used.
%     The silence label should be in the following format: starting time (tab) ending time
%     See examples in ../rtMRIdata/lab_sil
path.mri_data_dir = '../rtMRIdata/mat';
path.output_data_dir = '../out/seg';
path.morph_data_dir = '../out/morph';
path.sil_lab = '../rtMRIdata/lab_sil';
