function output = f_load_data_from_mat(file_path)

% If you have any question, please email to jangwon@usc.edu
% Jangwon Kim
% May 2nd 2014


tmp_data = load(file_path);
tmp_fieldname = fieldnames(tmp_data);
output = getfield(tmp_data,tmp_fieldname{1});

